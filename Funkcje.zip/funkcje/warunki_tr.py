
def warnuki_tr()->None:
    print("Aby istniał trójkąt o bokach a,b,c muszą być spełnione trzy warunki:")
    print("a < b + c")
    print("b < a + c")
    print("c < a + b")
    print("podaj 3 boki a program sprawdzi czy jest to trojkat")
    a = float(input("a: "))
    b = float(input("b: "))
    c = float(input("c: "))
    if a < b + c and b < a + c and c < a + b:
        print("Moze powstac trojkat o takich bokach")
    else:
        print("Nie moze powstac trockat o takich bokach")
