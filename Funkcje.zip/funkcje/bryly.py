from math import pi
PI = pi

#---------------------------------------------------------------------------------------------------------------------

def legenda_pp()->None:
    print("a - pp szescianu")
    print("b - pp prostopadloscianu")
    print("c - pp graniastoslupa")
    print("d - pp ostroslupa")
    print("e - pp walca")
    print("f - pp stozka")
    print("g - pp kuli")

#---------------------------------------------------------------------------------------------------------------------

def pola_powerzchni()->None:
    legenda_pp()
    inp = input().strip().lower()
    if inp == "a":
        a = float(input("a: "))
        print(f"Dla szescianu o boku {a} pp wynosi {pp_szescianu(a)}")
    elif inp == "b":
        a = float(input("a: "))
        b = float(input("b: "))
        c = float(input("c: "))
        print(f"Dla prostopadloscianu o dlugosciach {a},{b},{c} pp wynosi {pp_prostopadloscianu(a,b,c)}")
    elif inp == "c":
        a = float(input("a: "))
        b = float(input("b: "))
        print(f"Dla graniastoslupa o podstawie {a} i wysokosci {b} pp wynosi {pp_graniastoslupa(a,b)}")
    elif inp == "d":
        a = float(input("a: "))
        b = float(input("b: "))
        print(f"Dla ostroslupa o podstawie {a} i wysokosci {b} pp wynosi {pp_ostroslupa(a,b)}")
    elif inp == "e":
        r = float(input("r: "))
        H = float(input("H: "))
        print(f"Dla walca o promieniu {r} i wysokosci {H} pp wynosi {pp_walca(r,H)}")
    elif inp == "f":
        r = float(input("r: "))
        H = float(input("H: "))
        print(f"Dla stozka o promieniu {r} i wysokosci {H} pp wynosi {pp_stozka(r,H)}")
    elif inp == "g":
        r = float(input("r: "))
        print(f"Dla kuli o promieniu {r} pp wynosi {pp_kuli(r)}")
    else:
        print("Nie ma takiej komendy")

#---------------------------------------------------------------------------------------------------------------------

def pp_szescianu(a:float)->float:
    return 6*(a**2)

def pp_prostopadloscianu(a:float,b:float,c:float)->float:
    return 2*(a+b)+2*(b+c)+2*(a+c)

def pp_graniastoslupa(a:float,b:float)->float:
    return 2*a+b

def pp_ostroslupa(a:float,b:float)->float:
    return a+b

def pp_walca(r:float,H:float)->float:
    return 2*PI*(r**2)+2*PI*r*H

def pp_stozka(r:float,H:float)->float:
    return PI*(r**2)+PI*r*H

def pp_kuli(r:float)->float:
    return 4*PI*(r**2)

#---------------------------------------------------------------------------------------------------------------------

def bryly()->None:
    print("a - pola powierzchni")
    print("b - objetosc")
    inp = input().strip().lower()
    if inp == "a":
        pola_powerzchni()
    elif inp == "b":
        objetosc()
    else:
        print("Nie ma takiej komendy")

#---------------------------------------------------------------------------------------------------------------------

def legenda_ob()->None:
    print("a - ob szescianu")
    print("b - ob prostopadloscianu")
    print("c - ob graniastoslupa")
    print("d - ob ostroslupa")
    print("e - ob walca")
    print("f - ob stozka")
    print("g - ob kuli")

#---------------------------------------------------------------------------------------------------------------------

def objetosc()->None:
    legenda_ob()
    inp = input().lower().strip()
    if inp == "a":
        a = float(input("a: "))
        print(f"Objetosc szescianu o dlugosci {a} wynosi {ob_szescianu(a)}")
    elif inp == "b":
        a = float(input("a: "))
        b = float(input("b: "))
        c = float(input("c: "))
        print(f"Objetosc prostopadloscianu o dlugosciach {a},{b},{c} wynosi {ob_prostopadloscianu(a,b,c)}") 
    elif inp == "c":  
        a = float(input("a: "))
        b = float(input("b: "))
        print(f"Objetosc graniastoslupa o podstawie {a} i wysokosci {b} wynosi {ob_graniastoslupa(a,b)}")   
    elif inp == "d": 
        a = float(input("a: "))
        b = float(input("b: "))
        print(f"Objetosc ostroslupa o podstawie {a} i wysokosci {b} wynosi {ob_ostroslupa(a,b)}")   
    elif inp == "e":
        r = float(input("r: "))
        H = float(input("H: "))
        print(f"Objetosc walca o promieniu {r} i wysokosci {H} wynosi {ob_walca(r,H)}")
    elif inp == "f":
        r = float(input("r: "))
        H = float(input("H: "))
        print(f"Objetosc stozka o promieniu {r} i wysokosci {H} wynosi {ob_stozka(r,H)}")
    elif inp == "g":
        r = float(input("r: "))
        print(f"Objetosc kuli o promieniu {r} wynosi {ob_kuli(r)}")
    else:
        print("Nie ma takiej komendy")
#---------------------------------------------------------------------------------------------------------------------

def ob_szescianu(a:float)->float:
    return a**3

def ob_prostopadloscianu(a:float,b:float,c:float)->float:
    return a*b*c

def ob_graniastoslupa(a:float,b:float)->float:
    return a*b

def ob_ostroslupa(a:float,b:float)->float:
    return (1/3)*a*b

def ob_walca(r:float,H:float)->float:
    return PI*(r**2)*H

def ob_stozka(r:float,H:float)->float:
    return (1/3)*PI*(r**2)*H

def ob_kuli(r:float)->float:
    return (4/3)*PI*(r**3)


