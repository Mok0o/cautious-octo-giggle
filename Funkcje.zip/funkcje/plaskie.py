from math import pi
PI = pi

# Pola pp 
def pp_kwadartu(a:float)->float:
    return a**2

def pp_prostokatu(a:float,b:float)->float:
    return a*b

def pp_rownolegloboku(a:float,h:float)->float:
    return a*h

def pp_trapezu(a:float,b:float,h:float)->float:
    return ((a+b)*h)*2

def pp_trojkata(a:float,h:float)->float:
    return (a*h)*0.5

def pp_trojkata_r(a:float)->float:
    return (a**2)/4

def pp_kola(r:float)->float:
    return PI*(r**2)

def pp_rombu(a:float,h:float)->float:
    return a*h

def legenda_pp()->None:
    print("a - pp_kwadartu")
    print("b - pp prostokatu")
    print("c - pp rownolegloboku")
    print("d - pp trapezu")
    print("e - pp trojkata")
    print("f - pp trojkata rownobocznego")
    print("g - pp kola")
    print("h - pp rombu")

def pola_pp()->None:
    legenda_pp()
    int = input().lower().strip()
    if int == "a":
        a = float(input("a: "))
        print(f"Dla kwadrata o boku {a} pp wynosi {pp_kwadartu(a)}")
    elif int == "b":
        a = float(input("a: "))
        b = float(input("b: "))
        print(f"Dla prostokata o bokach {a} i {b} pp wynosi {pp_prostokatu(a,b)}")
    elif int == "c":
        a = float(input("a: "))
        b = float(input("b: "))
        print(f"Dla prostokata o bokach {a} i {b} pp wynosi {pp_prostokatu(a,b)}")
    elif int == "d":
        a = float(input("a: "))
        b = float(input("b: "))
        h = float(input("h: "))
        print(f"Dla trapezu o podstawach {a} , {b} i  wysokosci {h} pp wynosi {pp_trapezu(a,b,h)}")
    elif int == "e":
        a = float(input("a: "))
        h = float(input("h: "))
        print(f"Dla trojkata o podstawie {a} i wysokosci {h} pp wynosi {pp_trojkata(a,h)}")
    elif int == "f":
        a = float(input("a: "))
        h = float(input("h: "))
        print(f"Dla trojkata rownobocznego o podstawie {a} i wysokosci {h} pp wynosi {pp_trojkata_r(a,h)} * pierwiastek 3")
    elif int == "g":
        r = float(input("r: "))
        print(f"Dla kola o promieniu {r} pp wyniosi {pp_kola(r)}")
    elif int == "h":
        a = float(input("a: "))
        h = float(input("h: "))
        print(f"Dla trojkata o podstawie {a} i wysokosci {h} pp wynosi {pp_rombu(a,h)}")
    else:
        print("nie ma takiej komendy")
# Obwody 
def obw_kwadratu(a:float)->float:
    return 4*a

def obw_prostokata(a:float,b:float)->float:
    return 2*a+2*b

def obw_rownolegloboku(a:float,b:float)->float:
    return 2*a+2*b

def obw_trapezu(a:float,b:float,c:float,d:float)->float:
    return a+b+c+d

def obw_trojkata(a:float,b:float,c:float)->float:
    return a+b+c

def obw_trojkata_r(a:float)->float:
    return a*3

def obw_kola(r:float)->float:
    return 2*PI*r

def obw_rombu(a:float)->float:
    return a*4

def legenda_obw()->None:
    print("a - obw_kwadratu")
    print("b - obw_prostokata")
    print("c - obw_rownolegloboku")
    print("d - obw_trapezu")
    print("e - obw_trojkata")
    print("f - obw_trojkata rownoboczengo")
    print("g - obw_kola")
    print("h - obw_rombu")


def obwody()->None:
    legenda_obw()
    inp = input().lower().strip()
    if inp == "a":
        a = float(input("a: "))
        # wynik = obw_kwadratu(a)
        # print(f"Dla kwadratu o boku {a} obw = {wynik}")
        print(f"Dla kwadratu o boku {a} obw = {obw_kwadratu(a)}")
    elif inp == "b":
        a = float(input("a: "))
        b = float(input("b: "))
        print(f"Dla prostokata o bokach {a} i {b} obw = {obw_prostokata(a,b)}")
    elif inp == "c":
        a = float(input("a: "))
        b = float(input("b: "))
        print(f"Dla rownolegloboku o bokach {a} i {b} obw = {obw_rownolegloboku(a,b)}")
    elif inp == "d":
        a = float(input("a: "))
        b = float(input("b: "))
        c = float(input("c: "))
        d = float(input("d: "))
        print(f"Dla trapezu o bokach {a},{b},{c},{d} obw = {obw_trapezu(a,b,c,d)}")
    elif inp == "e":
        a = float(input("a: "))
        b = float(input("b: "))
        c = float(input("c: "))
        print(f"Dla trojkata o bokach {a},{b},{c} obw = {obw_trojkata(a,b,c)}")
    elif inp == "f":
        a = float(input("a: "))
        print(f"Dla trojkata rownobocznego o boku {a} obw = {obw_trojkata_r(a)}")
    elif inp == "g":
        r = float(input("r: "))
        print(f"Dla kola o promieniu {r} obw = {obw_kola(r)}")
    elif inp == "h":
        a = float(input("a: "))
        print(f"Dla rombu o boku {a} obw = {obw_rombu(a)}")
    else:
        print("nie ma takiej komendy")


# ----------------------------------------------

def plaskie()->None:
    print("Wzory na figury plaskie")
    print("a - pola pp")
    print("b - obwody")
    inp = input().lower().strip()
    if inp == "a":
        pola_pp()
    elif inp == "b":
        obwody()
    else:
        print("Nie ma takiej koendy")







