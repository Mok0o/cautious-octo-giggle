import plaskie as bl
import bryly as pl
import warunki_tr as ol

def legenda()->None:
    print("a - bryly")
    print("b - plaskie")
    print("c - warunki tr")
    print("e - wyjdz z programu")

def main()->None:
    while True:
        legenda()
        inp = input().lower().strip()
        if inp == "a":
            pl.bryly()
        elif inp == "b":
            bl.plaskie()
        elif inp == "c":
            ol.warnuki_tr()
        elif inp == "e":
            print("Program zkonczyl dzialanie")
            break
        else:
            print("Nie ma takiej komendy")

# --------------------------------------------------------------------------
main()




